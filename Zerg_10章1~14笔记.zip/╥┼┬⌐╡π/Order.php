<?php


namespace app\api\controller\v1;


use app\api\controller\BaseController;
use app\api\validate\OrderPlace;
use app\api\service\Token as TokenService;
use app\api\service\Order as OrderService;

class Order extends BaseController
{
    //用户选择好商品后向API提交包含它所选的商品相关信息
    //后端接收到信息后对该商品的库存量进行检测——因为客户端信息与服务端信息不一定同步！
    //有库存则将订单数据存入数据库——下单成功——返回客户端支付可执行消息
    //调用支付接口进行支付
    //还需要在此进行库存量检测
    //通过检测——服务器调用微信支付接口进行支付
    //微信返回支付结果，根据微信返回的支付结果对数据库库进行操作
    //（只要是服务器没有收到支付结果就不能操作数据库！）
    //支付成功——仍需要进行库存量检测（以防微信服务器延时或出bug）
    //成功且库存量还在——对库存量进行扣除

    protected $beforeActionList = [
        'checkExclusiveScope' => ['only' => 'placeOrder']
    ];

    public function placeOrder()
    {
        (new OrderPlace())->goCheck();
        $products = input('post.products/a');//获取数组参数必须加斜杠a
        $uid = TokenService::getCurrentUid();//获取用户uid

        $order = new OrderService();
        $status = $order->place($uid, $products);
        return $status;
    }
}