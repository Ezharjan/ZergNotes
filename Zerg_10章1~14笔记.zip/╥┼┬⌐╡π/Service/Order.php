<?php


namespace app\api\service;


use app\api\model\OrderProduct;
use app\api\model\Product;
use app\api\model\UserAddress;
use app\lib\exception\OrderException;
use app\lib\exception\UserException;
use think\Db;
use think\Exception;

class Order
{
    //订单的商品列表——用户传过来的商品参数
    protected $oProducts;

    //数据库里查询出来的真实的商品信息（包括库存量）
    protected $products;

    protected $uid;

    function __construct()
    {
    }

    /**下单方法：完成下单的接口
     * @param int $uid 用户id
     * @param array $oProducts 订单商品列表
     * @return array 订单商品状态
     * @throws Exception
     */
    public function place($uid, $oProducts)
    {
        //对比两个传进来的参数
        //将products从数据库里查出来
        $this->oProducts = $oProducts;
        $this->products = $this->getProductsByOrder($oProducts);
        $this->$uid = $uid;
        $status = $this->getOrderStatus();
        if (!$status['pass']) {//库存量检测没有通过
            $status['order_id'] = -1;//新增并赋值
            return $status;
        }

        //如果库存量检测为true——创建订单
        $orderSnap = $this->snapOrder($status);
        $order = $this->createOrder($orderSnap);
        $order['pass'] = true;
        return $order;
    }

    //生成订单数据并将其输入到数据库中去
    private function createOrder($snap)
    {
        Db::startTrans();//事务始
        try {
            $orderNo = $this->makeOrderNo();
            $order = new app\api\model\Order();//因为模型和服务重名，故用完整路径名表示
            $order->user_id = $this->uid;
            $order->order_no = $orderNo;
            $order->total_price = $snap['orderPrice'];
            $order->total_count = $snap['totalCount'];
            $order->snap_img = $snap['snapImg'];
            $order->snap_name = $snap['snapName'];
            $order->snap_address = $snap['snapAddress'];
            $order->snap_items = json_encode($snap['pStatus']);//数组要序列化一下

            $order->save();//写入数据库中

            $orderID = $order->id;//获取用户的ID
            $create_time = $order->create_time;
            foreach ($this->oProducts as &$p) {//加引用符号才能对数据里面的数据进行操作
                $p['order_id'] = $orderID;//为oProducts在数据库的表中新增一个字段值
                Db::commit();//事务终
            }
            $orderProduct = new OrderProduct();
            $orderProduct->saveAll($this->oProducts);//新增完这个字段值之后再全部存储
            return [
                'order_no' => $orderNo,
                'order_id' => $orderID,
                'create_time' => $create_time];
        } catch (Exception $ex) {
            Db::rollback();
            throw $ex;
        }
    }

    public static function makeOrderNo()//生成订单号【高并发情况下不太推荐】
    {
        $yCode = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K');
        $orderSn =
            $yCode[intval(date('Y')) - 2020] . strtoupper(dechex(date('m')))
            . data('d') . substr(time(), -5) . substr(microtime(), 2, 5)
            . sprintf('%02d', rand(0, 99));//生成订单好，进一步缩小重复概率
        return $orderSn;
    }

    //生成订单快照——保存订单的当前状态
    private function snapOrder($status)
    {
        $snap = [
            'orderPrice' => 0,
            'totalCount' => 0,
            'pStatus' => [],
            'snapAddress' => null,
            'snapName' => '',
            'snapImg' => ''
        ];

        $snap['orderPrice'] = $status['orderPrice'];
        $snap['totalCount'] = $status['totalCount'];
        $snap['pStatus'] = $status['pStatusArray'];
        $snap['snapAddress'] = json_encode($this->getUserAddress());
        $snap['snapName'] = $this->products[0]['name'];//取第一个
        $snap['snapImg'] = $this->products[0]['main_img_url'];

        //帮客户端做好多选商品在名称候面加“等”字
        if (count($this->products) > 1) {
            $snap['snapName'] .= '等';
        }
    }

    private function getUserAddress()
    {
        $userAddress = UserAddress::where('user_id', '=', $this->uid)
            ->find();
        if (!$userAddress) {
            throw new UserException([
                'msg' => '用户收获地址不存在，下单失败',
                'errorCode' => 60001,
            ]);
        }
        return $userAddress->toArray();
    }

    private function getOrderStatus()//库存量检测
    {
        $status = [
            'pass' => true,
            'orderPrice' => 0,//订单总价格（所有商品）
            'totalCount' => 0,
            'pStatusArray' => []//用来保存订单里面的所有详细信息
        ];

        foreach ($this->oProducts as $oProduct) {
            $pStatus = $this->getProductStatus(
                $oProduct['product_id'], $oProduct['count'], $this->products
            );
            if ($pStatus['haveStock']) {//只要有一个不成功，则所有的订单都不通过
                $status['pass'] = false;
            }
            //单个类别商品总价格累加获得所有商品价格
            $status['orderPrice'] += $pStatus['totalPrice'];

            $status['totalCount'] += $pStatus['count'];

            //将获取的信息都存入到一个数组中
            array_push($status['pStatusArray'], $pStatus);
        }
        return $status;
    }

    private function getProductStatus($oPID, $oCount, $products)
    {
        $pIndex = -1;//oPID在products数组里面的序号

        $pStatus = [
            'id' => null,
            'haveStock' => false,
            'count' => 0,
            'name' => '',
            'totalPrice' => 0 //当前某一类商品的总价格
        ];

        for ($i = 0; $i < count($products); $i++) {
            if ($oPID == $products[$i]['id']) { //找到对应的商品
                $pIndex = $i;
            }
        }
        if ($pIndex == -1) {//如果没有对应上，值仍旧是-1——表示订单不存在
            throw new OrderException([
                'msg' => 'id为' . $oPID . '的商品不存在，创建订单失败。'
            ]);
        } else { //当存在时
            $product = $products[$pIndex];
            $pStatus['id'] = $product['id'];
            $pStatus['name'] = $product['name'];
            $pStatus['count'] = $oCount;
            $pStatus['totalPrice'] = $product['price'] * $oCount;
            if ($product['stock'] - $oCount >= 0) {
                $pStatus['haveStock'] = true;
            }
        }
        return $pStatus;
    }

    //根据订单查找真实的商品信息
    private function getProductsByOrder($oProducts)
    {
//        foreach ($oProducts as $oProduct) {
//            //循环查询数据库——会让服务器崩溃
//        }
        $oPIDs = [];
        foreach ($oProducts as $item) {
            array_push($oPIDs, $item['product_id']);
        }
        $products = Product::all($oPIDs)        //指明数据库中需要看到的字段
            ->visible(['id', 'price', 'stock', 'name', 'main_img_url'])
            ->toArray();
        return $products;
    }
}