<?php


namespace app\sample\controller;

//第二种方式
use think\Request;

class Test
{
//public function hello(){
//    //http://localhost:88/zerg/public/index.php/sample/test/hello
//    //D:\Anaconda3\XAMPP\apache\conf\extra
//    //httpd-vhosts  #ignore them
//    return 'Hello Alexander!';
//}
//第一种方式
//    public function hello($id, $name,$age)
//    {
//        //http://localhost:88/zerg/public/index.php/hello/123?name=rrrrrrr
//        //post请求的时候在body中将key的值传入成age，再随便传入value参数即可
//        echo $id;
//        echo '|';
//        echo $name;
//        echo '|';
//        echo $age;
//    }



//第二种方式---->一定要在外部导入think\Request

//    public function hello()
//    {
//        $id = Request::instance()->param('id');//param是不区分request请求是get还是其他类型
//        $name = Request::instance()->param('name');
//        $age = Request::instance()->param('age');
//        echo $id;
//        echo '|';
//        echo $name;
//        echo '|';
//        echo $age;
//    }

//    public function hello()
//    {
//        //获取所有的变量
//        $all = Request::instance()->param();//param是不区分request请求是get还是其他类型
//        var_dump($all);//s输出数组
//    }

//第三种方式
    public function hello()
    {
        //获取所有的变量
        //$all = Request::instance()->get();//改成get之后只获取get请求下的变量
//        $all = Request::instance()->route();//改成route之后可以获取路径下的id参数
//        $all = Request::instance()->post();//改成post之后可以获取post的参数
//        $all = input('param.'); //获取所有数据的第三种方式

        $all = input('param.name'); //获取单个变量的方式是在param后面加一个点之后再加上其参数
        $all = input('post.name'); //也可以把param换成其他类型的请求
        var_dump($all);//s输出数组
    }


//使用依赖注入的方式
    public function new_hello(Request $request)
    {
        //获取所有的变量
        $all = $request->param();
        var_dump($all);//s输出数组
    }

}