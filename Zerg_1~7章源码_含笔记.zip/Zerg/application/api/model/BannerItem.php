<?php

namespace app\api\model;

use think\Model;

class BannerItem extends Model
{
    //
}
