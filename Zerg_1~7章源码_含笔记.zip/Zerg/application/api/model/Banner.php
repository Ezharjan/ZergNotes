<?php


namespace app\api\model;

use think\Db;
use think\Model;

class Banner extends Model
{
    ////7.11
    //protected $table = 'category';//对应的数据对象


    public static function getBannerByID($id){
        //TODO:根据Banner ID号  获取Banner信息
/////6.4
//        try {
//            1 / 0;
//        }catch(Exception $exception){
//            //可以记录日志
//            throw $exception;
//        }
//        return 'this is banner info';

        ////6.5
        //return null;

        ////7.1：使用原生的数据库查询语句
//        $result = Db::query('select * from banner_item where banner_id=?', [$id]);
//        return $result;

        ////7.4使用查询构建器对数据库进行操作；链式调用的方法
        $result = Db::table('banner_item')->where('banner_id','=',$id)->select();
        //不加find方法调用时返回的是query对象；然而find方法只能返回一维数组；select方法则能返回集
        //where(字段名，表达式，查询条件);//等号可以省略，参照查询语法，不区分大小写。
        //where有三种写法：表达式、数组法、闭包
        ////闭包的方式实现上面的结果
//        where(function ($query) use ($id){
//            $query -> where('banner_id','=',$id);
//        })
//        return $result;
        //数据库真正的执行方法：select(); find(); update(); delete(); insert();

        //使用非链式方法，结果同上
//        Db::table('banner_item');
//        Db::where('banner_id','=',$id);
//        $result =  Db::select();//一次调用，状态会被清除掉！
//        //$result =  Db::select();//将会为空状态，不会留存上一个状态！
//        return $result;
        ////7.5
        $result = Db::table('banner_item')
            //->fetchSql()
            ->where(function ($query) use ($id){
                    $query -> where('banner_id','=',$id);
            })
            ->select();
        return $result;




    }
}