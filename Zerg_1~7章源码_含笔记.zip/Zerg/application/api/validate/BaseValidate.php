<?php

namespace app\api\validate;

use app\lib\exception\ParameterException;
use think\Request;
use think\Validate;

class BaseValidate extends Validate
{
    public function goCheck()
    {
        //获取http传入的参数
        //对这些参数进行校验
        $request = Request::instance();
        $params = $request->param();//获取所有参数

        $result = $this->batch()->check($params);//批量印出
        if (!$result) {
            //$error = $this->error;
            //throw new Exception($error);//抛出TP5的默认异常
            $e = new ParameterException([
                //'msg' => 'test',
                'msg' => $this->error,
//                'code' => 400,
//                'errorCode' => 10002
            ]);
//            $e->msg = $this->error;
//            $e->errCode = 10002;//取值和初始化
            throw $e;
        } else {
            return true;
        }
    }
}