<?php


namespace app\api\validate;


use think\Validate;

class IDMustBePositiveInt extends BaseValidate
{
    protected $rule = [
        //自定义验证规则
        'id' => 'require|isPositiveInteger',
        //'num' =>'in:1,2,3'
    ];

    protected function isPositiveInt($value, $rule = '', $data = '', $field = '')
    {
        if ($value){
            //是不是数字？                    是不是整型？      是不是大于零的？
            if (is_numeric($value) && is_int($value +0) && ($value+0 > 0)){
                return true;
            }
        }else{
            return $field.'必须是整数';
        }
    }
}