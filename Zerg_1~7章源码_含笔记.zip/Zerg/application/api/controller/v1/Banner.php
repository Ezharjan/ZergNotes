<?php


namespace app\api\controller\v1;

use app\api\validate\IDMustBePositiveInt;
use app\api\validate\TestValidate;
use app\lib\exception\BannerMissException;
use think\Exception;
use think\Validate;
use app\api\model\Banner as BannerModel;// 给一个别名；当然，也可以直接重命名类
class Banner
{
    /**
     * 获取指定id的Banner信息
     * @url /banner/:id
     * @http GET
     * @id Banner的id号
     */
    public function getBanner($id)
    {//根据Banner ID 获取Banner信息

        /*独立验证
        //验证的数据
        $data = [
            'name' => 'vendqqqqqqqqqqqqqqqqor',
            'email' => 'vendor@@qq.com'//故意写错
        ];

        //验证的规则
        $validate = new Validate([
            //下方是TP5内置的验证规则--->官方文档-->验证-->内置规则
           'name' => 'require|max:10',
            'email' => 'email'
        ]);

        //执行验证
//        $result = $validate->check($data);
        //------->在本段末尾打断点执行调试以查看data数据是否符合执行验证的规则，看result真假

        //执行批量验证，返回结果为数组，所以不能使用echo输出而是用var_dump(content);
        $result = $validate->batch()->check($data);



        //输出错误的原因
//        echo $validate->getError();
        var_dump($validate->getError());//返回的数组类型不能再采用echo输出了
        //Postman中的报错提示结果：
        //  'name' => string 'name长度不能超过 10' (length=25)
        //  'email' => string 'email格式不符' (length=17)

        *///这种独立验证方式基本上不采用，推荐采用验证器的方式做验证

        /*验证器
        //验证的数据
        $data = [
            'name' => 'vendqqqqqqqqqqqqqqqqor',
            'email' => 'vendor@@qq.com'//故意写错
        ];

        $validate = new TestValidate();
        $result = $validate->batch()->check($data);
        var_dump($validate->getError());
        //Postman中输出结果跟独立验证是一样的，但是后续的环境下会体现验证器的优势
    *///验证其的验证方式

        /*
        $data = [
            'id' => $id
        ];

        $validate = new IDMustBePositiveInt();
        $result = $validate->batch()->check($data);
        if ($result){

        }else{

        }
*///自定义的第一种检验方式

//        (new IDMustBePositiveInt())->goCheck();//类似于拦截器
//        $c = 1;
//        $banner = BannerModel::getBannerByID($id);
//        return $banner;


        /////6.2
//        (new IDMustBePositiveInt())->goCheck();//类似于拦截器
//        try{
//            $banner = BannerModel::getBannerByID($id);
//        }catch (Exception $exception){
//            $error = [
//                'errer_code' => 10001,
//                'msg' => $exception->getMessage()
//            ];
//            return json($error,400);
//        }
//        return $banner;


        ////6.4--------------------待审
        //(new IDMustBePositiveInt())->goCheck();//类似于拦截器

//        $banner = BannerModel::get($id);//使用think内部提供的基类
        $banner = BannerModel::find($id);//效果同上
        //get, find, all, select
//        $banner = new BannerModel();
//        $banner = $banner->get($id);
        //$banner = BannerModel::getBannerByID($id);

        if (!$banner) {
            //throw new BannerMissException();//集中在异常处理类库，却只在一处抛出
            //throw new Exception('Test Log:内部错误!');//6.7修改这里的Exception----测试Log日志
            throw new BannerMissException();
        }
//        return json($banner);//$banner;
        return $banner;//使用think内部的基类时不必使用json去接
    }
}